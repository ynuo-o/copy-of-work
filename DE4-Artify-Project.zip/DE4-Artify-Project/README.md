# DE4-DVS Artify Project

**Project 4: "Artify" Photographs** — Two artistic styles using **Mean-Shift** (required) and techniques from Labs 2–5. **Option B**: Differentiated from teammate's watercolor/oil style.

## Styles (Visually Distinct)

| Style | Effect | Key Difference from Teammate |
|-------|--------|------------------------------|
| **Poster / Pop Art** | Flat colors, high contrast, strong edges | Graphic vs. soft watercolor |
| **Cartoon** | Clean regions, sharp edges, comic look | Crisp vs. painterly oil |
| **Sketch** | Pencil sketch, edge-based | Line drawing style |

## Pipelines

### Style 1: Poster / Pop Art
1. **Mean-Shift** color quantization (Lab5)
2. **Contrast stretching** (Lab3): `s = 1/(1+(k/r)^E)`
3. **Sobel** edge detection (Lab5)
4. Edge overlay

### Style 2: Cartoon
1. **imopen** morphological simplification (Lab4)
2. **Mean-Shift** segmentation (Lab5)
3. **LoG** edge detection (Lab5)
4. Edge overlay
5. **histeq** (Lab3)
6. **medfilt2** (Lab3)

### Style 3: Sketch
1. **Mean-Shift** color quantization (Lab5)
2. **rgb2gray** (Lab2)
3. **edge(Canny)** (Lab3)
4. Invert for pencil effect

## How to Run

**Option A – GUI App (recommended):**
```matlab
cd matlab
artify_app
```
Modern window with image preview, style dropdown, parameter fields, Process/Save buttons. Requires MATLAB R2016a+.

**Option B – Script mode:**
```matlab
main
```
Step-by-step dialogs.

**Interactive workflow:**
1. **Select image** – File dialog opens
2. **Choose style** – Poster, Cartoon, Sketch, or All three
3. **Adjust parameters** – Tune numbers for different effects (same style, different look)
4. **Select save folder** – (Cancel = no save)
5. Results display and auto-save

**Parameter tuning:** Each style has 4 adjustable parameters. Changing them produces different effects within the same style (e.g., more/fewer colors, stronger/softer edges).

## Parameters (user-adjustable in app)

| Style | Parameter | Effect |
|-------|-----------|--------|
| Poster | Color BW | Smaller = more colors |
| Poster | nSeeds | More = finer, slower |
| Poster | Edge strength | Higher = darker outlines |
| Poster | E (contrast) | Steeper = more contrast |
| Cartoon | Spatial BW | Larger = bigger regions |
| Cartoon | Color BW | Smaller = more colors |
| Cartoon | Edge strength | Higher = darker outlines |
| Cartoon | SE size | Larger = more simplification |
| Sketch | Color BW | Smaller = cleaner lines |
| Sketch | nSeeds | Mean-Shift seeds |
| Sketch | Edge thresh | Canny sensitivity |
| Sketch | Line str | Line darkness |

## Course Connections

| Lab | Techniques |
|-----|------------|
| Lab2 | RGB color space |
| Lab3 | Contrast stretching, histeq, medfilt2, edge |
| Lab4 | strel, imopen |
| Lab5 | Mean-Shift (RGB + RGBXY), edge(Sobel/LoG) |

## File Structure

```
matlab/
├── artify_app.m         # GUI app (recommended)
├── main.m               # Script mode
├── getParameters.m
├── meanShiftSegmentation.m
├── meanShiftColorQuant.m
├── artify_poster.m
├── artify_cartoon.m
└── artify_sketch.m
```

## Evidence / Evaluation

### Quantitative Metrics

The GUI app reports **SSIM** (Structural Similarity Index) and **processing time** for each result. SSIM measures perceptual similarity between original and stylized image (0–1, higher = more similar).

| Style | Typical SSIM | Notes |
|-------|--------------|-------|
| Poster / Pop Art | 0.5–0.8 | Lower due to flat colors and strong edges |
| Cartoon | 0.5–0.75 | Region simplification reduces similarity |
| Sketch | 0.3–0.6 | Grayscale + edges diverge most from original |

*Add your own SSIM values here after running on sample images.*

### Sample Results

*Add screenshots of your results here, e.g.:*

- `evidence/poster_example.png` – Poster effect on landscape
- `evidence/cartoon_example.png` – Cartoon effect on portrait
- `evidence/sketch_example.png` – Sketch effect comparison

To generate evidence: run `artify_app`, load an image, process each style, and use **Save Result** or the comparison slider to capture before/after views.

## Optional Future Enhancements

- **Batch processing** – Process folder of images
