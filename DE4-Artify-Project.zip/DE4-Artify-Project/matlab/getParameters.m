function [pPoster, pCartoon, pSketch] = getParameters(styleChoice)
% GETPARAMETERS  User-adjustable parameters for Artify styles.
%   Returns struct(s) with validated values. Empty if user cancels.
%
%   styleChoice: 1=Poster, 2=Cartoon, 3=Sketch, 4=All three

pPoster = []; pCartoon = []; pSketch = [];

%% Poster parameters (colorBW, nSeeds, edgeStrength, E)
if styleChoice == 1 || styleChoice == 4
    def = {'0.08', '400', '0.5', '0.9'};
    prompts = {
        'Color bandwidth (0.05-0.15, smaller=more colors)'
        'Mean-Shift seeds (200-600, more=slower but finer)'
        'Edge strength (0.2-0.8, darker outlines)'
        'Contrast E (0.5-1.5, steeper=more contrast)'
        };
    resp = inputdlg(prompts, 'Poster / Pop Art - Parameters', 1, def);
    if isempty(resp), return; end
    pPoster.colorBW     = parseNum(resp{1}, 0.08, 0.05, 0.15);
    pPoster.nSeeds      = round(parseNum(resp{2}, 400, 200, 600));
    pPoster.edgeStrength = parseNum(resp{3}, 0.5, 0.2, 0.8);
    pPoster.E           = parseNum(resp{4}, 0.9, 0.5, 1.5);
end

%% Cartoon parameters (spatialBW, colorBW, edgeStrength, seSize)
if styleChoice == 2 || styleChoice == 4
    def = {'10', '0.1', '0.45', '2'};
    prompts = {
        'Spatial bandwidth (5-20, larger=bigger regions)'
        'Color bandwidth (0.05-0.2, smaller=more colors)'
        'Edge strength (0.2-0.7, darker outlines)'
        'Morphology SE size (1-5, larger=more simplification)'
        };
    resp = inputdlg(prompts, 'Cartoon - Parameters', 1, def);
    if isempty(resp), return; end
    pCartoon.spatialBW   = parseNum(resp{1}, 10, 5, 20);
    pCartoon.colorBW    = parseNum(resp{2}, 0.1, 0.05, 0.2);
    pCartoon.edgeStrength = parseNum(resp{3}, 0.45, 0.2, 0.7);
    pCartoon.seSize     = round(parseNum(resp{4}, 2, 1, 5));
end

%% Sketch parameters (colorBW, nSeeds, edgeThresh, lineStrength)
if styleChoice == 3 || styleChoice == 4
    def = {'0.06', '300', '0.15', '0.9'};
    prompts = {
        'Color bandwidth (0.04-0.1, simpler=cleaner lines)'
        'Mean-Shift seeds (200-400)'
        'Edge threshold (0.1-0.3, Canny sensitivity)'
        'Line strength (0.5-1, higher=dark lines)'
        };
    resp = inputdlg(prompts, 'Sketch - Parameters', 1, def);
    if isempty(resp), return; end
    pSketch.colorBW      = parseNum(resp{1}, 0.06, 0.04, 0.1);
    pSketch.nSeeds       = round(parseNum(resp{2}, 300, 200, 400));
    pSketch.edgeThresh   = parseNum(resp{3}, 0.15, 0.1, 0.3);
    pSketch.lineStrength = parseNum(resp{4}, 0.9, 0.5, 1);
end

end

function v = parseNum(str, default, lo, hi)
% Parse string to number, clamp to [lo,hi], use default if invalid
v = str2double(str);
if isnan(v), v = default; end
v = max(lo, min(hi, v));
end
