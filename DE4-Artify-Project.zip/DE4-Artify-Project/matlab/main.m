%% DE4-DVS Artify Project - Script Mode
%  Step-by-step dialogs. For GUI app, run: artify_app
%
%  Run: main  (or artify_app for modern GUI)

clear; clc; close all;

%% Step 1: Select image
[filename, pathname] = uigetfile({'*.jpg;*.jpeg;*.png;*.bmp;*.tif;*.tiff', 'Image files (*.jpg, *.png, etc.)'; ...
    '*.*', 'All files'}, 'Select an image to artify');
if filename == 0
    fprintf('Cancelled. Using default image.\n');
    try
        img = imread('peppers.png');
        [~, filename, ~] = fileparts('peppers.png');
    catch
        img = imread('football.jpg');
        [~, filename, ~] = fileparts('football.jpg');
    end
else
    img = imread(fullfile(pathname, filename));
    [~, filename, ~] = fileparts(filename);
    fprintf('Loaded: %s\n', filename);
end

if size(img, 3) == 1
    img = repmat(img, [1 1 3]);
end
img = im2double(img);

%% Step 2: Select style(s)
[styleChoice, ok] = listdlg('ListString', {'Poster / Pop Art', 'Cartoon', 'Sketch', 'All three'}, ...
    'SelectionMode', 'single', 'Name', 'Artify - Style Selection', ...
    'PromptString', 'Choose artistic style:', 'ListSize', [250 100]);
if ~ok || isempty(styleChoice)
    fprintf('Cancelled.\n');
    return;
end

%% Step 3: Adjust parameters (same style, different effects)
[pPoster, pCartoon, pSketch] = getParameters(styleChoice);
if isempty(pPoster) && isempty(pCartoon) && isempty(pSketch)
    fprintf('Cancelled.\n');
    return;
end

%% Step 4: Select save folder
saveFolder = uigetdir(pwd, 'Select folder to save results (Cancel = no save)');
doSave = (saveFolder ~= 0);

%% Step 5: Process selected style(s)
outPoster = []; outCartoon = []; outSketch = [];
if ~isempty(pPoster)
    fprintf('Processing Poster / Pop Art...\n');
    outPoster = artify_poster(img, pPoster.colorBW, pPoster.nSeeds, pPoster.edgeStrength, pPoster.E);
end
if ~isempty(pCartoon)
    fprintf('Processing Cartoon...\n');
    outCartoon = artify_cartoon(img, pCartoon.spatialBW, pCartoon.colorBW, pCartoon.edgeStrength, pCartoon.seSize);
end
if ~isempty(pSketch)
    fprintf('Processing Sketch...\n');
    outSketch = artify_sketch(img, pSketch.colorBW, pSketch.nSeeds, pSketch.edgeThresh, pSketch.lineStrength);
end

%% Step 6: Display results
nOut = ~isempty(outPoster) + ~isempty(outCartoon) + ~isempty(outSketch);
figure('Name', 'Artify - Results');
subplot(1, nOut + 1, 1); imshow(img); title('Original');
idx = 2;
if ~isempty(outPoster)
    subplot(1, nOut + 1, idx); imshow(outPoster); title('Poster / Pop Art');
    idx = idx + 1;
end
if ~isempty(outCartoon)
    subplot(1, nOut + 1, idx); imshow(outCartoon); title('Cartoon');
    idx = idx + 1;
end
if ~isempty(outSketch)
    subplot(1, nOut + 1, idx); imshow(outSketch); title('Sketch');
end

%% Step 7: Auto-save
if doSave
    if ~isempty(outPoster)
        fpath = fullfile(saveFolder, [filename '_poster.png']);
        imwrite(outPoster, fpath);
        fprintf('Saved: %s\n', fpath);
    end
    if ~isempty(outCartoon)
        fpath = fullfile(saveFolder, [filename '_cartoon.png']);
        imwrite(outCartoon, fpath);
        fprintf('Saved: %s\n', fpath);
    end
    if ~isempty(outSketch)
        fpath = fullfile(saveFolder, [filename '_sketch.png']);
        imwrite(outSketch, fpath);
        fprintf('Saved: %s\n', fpath);
    end
end

fprintf('Done!\n');
