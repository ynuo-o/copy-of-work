function out = artify_cartoon(img, spatialBW, colorBW, edgeStrength, seSize)
% ARTIFY_CARTOON  Style 2: Cartoon / Comic effect.
%   Clean regions, sharp edges - visually distinct from oil painting.
%
%   Pipeline: imopen (Lab4) → Mean-Shift segmentation → LoG edge → histeq
%
%   Course connections:
%   - Lab3: edge(LoG), histeq, medfilt2
%   - Lab4: strel, imopen (removes small objects)
%   - Lab5: Mean-Shift segmentation, feature vectors [R,G,B,x,y]
%
%   Inputs:
%     img          - RGB image (path or matrix)
%     spatialBW    - Mean-Shift spatial bandwidth (default 10)
%     colorBW      - Mean-Shift color bandwidth (default 0.1)
%     edgeStrength - Edge darkness 0-1 (default 0.45)
%     seSize       - imopen structuring element radius (default 2)

if nargin < 5, seSize = 2; end
if nargin < 4, edgeStrength = 0.45; end
if nargin < 3, colorBW = 0.1; end
if nargin < 2, spatialBW = 10; end

if ischar(img) || isstring(img), img = imread(img); end
if size(img, 3) == 1, img = repmat(img, [1 1 3]); end
img = im2double(img);

%% Stage 1: Morphological opening (Lab4 Task 2)
% imopen = erosion + dilation - removes small bright details
se = strel('disk', seSize);
for c = 1:3
    img(:, :, c) = imopen(img(:, :, c), se);
end

%% Stage 2: Mean-Shift segmentation (Lab5 - required)
[segmented, ~] = meanShiftSegmentation(img, spatialBW, colorBW);

%% Stage 3: LoG edge detection (Lab5 Task 2)
% Laplacian of Gaussian - different edge character from Canny
gray = rgb2gray(segmented);
edges = edge(gray, 'LoG', 0.001, 2);

%% Stage 4: Edge overlay
out = segmented;
for c = 1:3
    ch = out(:, :, c);
    ch(edges) = ch(edges) * (1 - edgeStrength);
    out(:, :, c) = ch;
end

%% Stage 5: Histogram equalization (Lab3 Task 3)
% Flattens histogram for enhanced contrast
for c = 1:3
    out(:, :, c) = histeq(out(:, :, c));
end

%% Stage 6: Light median filter (Lab3) - soften block boundaries
for c = 1:3
    out(:, :, c) = medfilt2(out(:, :, c), [2 2]);
end

out = max(0, min(1, out));

end
