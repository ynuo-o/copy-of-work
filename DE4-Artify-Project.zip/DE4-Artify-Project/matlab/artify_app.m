%% Artify App - Modern GUI
%  Run: artify_app
%  Features: 3 styles, parameter hints, quantitative eval, before/after slider

function artify_app()
if ~exist('uifigure', 'file')
    errordlg('Artify App requires MATLAB R2016a or later. Use main.m instead.', 'Artify');
    return;
end

fig = uifigure('Name', 'Artify - Photo to Artwork', 'Position', [80 80 980 620], ...
    'Color', [0.96 0.96 0.96], 'Resize', 'on');

fig.UserData.img = [];
fig.UserData.filename = '';
fig.UserData.result = [];
fig.UserData.lastStyle = '';

gl = uigridlayout(fig, [1 2], 'ColumnWidth', {320, '1x'}, 'Padding', [10 10 10 10], 'ColumnSpacing', 15);

%% Left: Controls
leftPanel = uipanel(gl, 'Title', 'Controls', 'FontWeight', 'bold', 'FontSize', 11, 'BackgroundColor', [1 1 1]);
leftLayout = uigridlayout(leftPanel, [8 1], 'RowHeight', {32, 28, 'fit', 'fit', 35, 'fit', 'fit', 'fit'}, 'RowSpacing', 6);

uibutton(leftLayout, 'Text', 'Load Image', 'ButtonPushedFcn', @(b,e) loadImage(ancestor(b,'figure')));

uilabel(leftLayout, 'Text', 'Style:');
styleDrop = uidropdown(leftLayout, 'Items', {'Poster / Pop Art', 'Cartoon', 'Sketch'}, ...
    'ValueChangedFcn', @(d,e) switchParams(ancestor(d,'figure')));
fig.UserData.styleDrop = styleDrop;

% Single parameter panel - same position for all styles, content updates on switch
paramPanel = uipanel(leftLayout, 'Title', 'Parameters', 'FontSize', 10);
paramGrid = uigridlayout(paramPanel, [4 3], 'RowHeight', repmat({36}, 1, 4), 'ColumnWidth', {95, 75, '1x'});
fig.UserData.paramLabels = gobjects(4, 1);
fig.UserData.paramEdits = gobjects(4, 1);
fig.UserData.paramHints = gobjects(4, 1);
for i = 1:4
    lbl = uilabel(paramGrid, 'Text', '');
    lbl.Layout.Row = i; lbl.Layout.Column = 1;
    ed = uieditfield(paramGrid, 'numeric');
    ed.Layout.Row = i; ed.Layout.Column = 2;
    hnt = uilabel(paramGrid, 'Text', '', 'FontSize', 10, 'FontColor', [0.3 0.3 0.3], 'WordWrap', 'on');
    hnt.Layout.Row = i; hnt.Layout.Column = 3;
    fig.UserData.paramLabels(i) = lbl;
    fig.UserData.paramEdits(i) = ed;
    fig.UserData.paramHints(i) = hnt;
end
switchParams(fig);  % Init content

uibutton(leftLayout, 'Text', 'Process', 'FontWeight', 'bold', 'BackgroundColor', [0.2 0.5 0.8], ...
    'FontColor', [1 1 1], 'ButtonPushedFcn', @(b,e) processImage(ancestor(b,'figure')));

uibutton(leftLayout, 'Text', 'Save Result', 'ButtonPushedFcn', @(b,e) saveResult(ancestor(b,'figure')));

fig.UserData.evalLabel = uilabel(leftLayout, 'Text', '', 'WordWrap', 'on', 'FontColor', [0.3 0.3 0.3]);
fig.UserData.statusLabel = uilabel(leftLayout, 'Text', 'Load an image to start.', 'WordWrap', 'on');

%% Right: Preview + Slider
rightPanel = uipanel(gl, 'Title', 'Preview', 'FontWeight', 'bold', 'FontSize', 11, 'BackgroundColor', [0.94 0.94 0.94]);
rightLayout = uigridlayout(rightPanel, [3 1], 'RowHeight', {'1x', 55, 28}, 'RowSpacing', 6);

axComp = uiaxes(rightLayout, 'BackgroundColor', [0.9 0.9 0.9]);
title(axComp, 'Original | Result (drag slider to compare)');
axis(axComp, 'off');

sliderPanel = uipanel(rightLayout, 'BorderType', 'none', 'BackgroundColor', [0.94 0.94 0.94]);
sliderLayout = uigridlayout(sliderPanel, [2 1], 'RowHeight', {28, 22});
fig.UserData.slider = uislider(sliderLayout, 'Limits', [0 100], 'Value', 50, ...
    'ValueChangedFcn', @(s,e) updateSliderView(ancestor(s,'figure')));
try
    fig.UserData.slider.MajorTicks = [];  % Hide tick numbers to avoid overlap
catch
end
fig.UserData.sliderLabel = uilabel(sliderLayout, 'Text', 'Left=Original  |  Right=Result', ...
    'FontSize', 11, 'FontColor', [0.4 0.4 0.4]);

fig.UserData.axComp = axComp;
fig.UserData.fig = fig;
end

function switchParams(fig)
style = fig.UserData.styleDrop.Value;
L = fig.UserData.paramLabels;
E = fig.UserData.paramEdits;
H = fig.UserData.paramHints;
if strcmp(style, 'Poster / Pop Art')
    L(1).Text = 'Color BW';     H(1).Text = 'Range: 0.05-0.15. Smaller=more colors';
    L(2).Text = 'nSeeds';       H(2).Text = 'Range: 200-600. More=slower,finer';
    L(3).Text = 'Edge str';     H(3).Text = 'Range: 0.2-0.8. Higher=darker outlines';
    L(4).Text = 'E';            H(4).Text = 'Range: 0.5-1.5. Steeper=more contrast';
    E(1).Value = 0.08; E(2).Value = 400; E(3).Value = 0.5; E(4).Value = 0.9;
elseif strcmp(style, 'Cartoon')
    L(1).Text = 'Spatial BW';   H(1).Text = 'Range: 5-20. Larger=bigger regions';
    L(2).Text = 'Color BW';     H(2).Text = 'Range: 0.05-0.2. Smaller=more colors';
    L(3).Text = 'Edge str';     H(3).Text = 'Range: 0.2-0.7. Higher=darker outlines';
    L(4).Text = 'SE size';      H(4).Text = 'Range: 1-5. Larger=more simplification';
    E(1).Value = 10; E(2).Value = 0.1; E(3).Value = 0.45; E(4).Value = 2;
else
    L(1).Text = 'Color BW';     H(1).Text = 'Range: 0.04-0.1. Simpler=cleaner lines';
    L(2).Text = 'nSeeds';       H(2).Text = 'Range: 200-400. Mean-Shift seeds';
    L(3).Text = 'Edge thresh';  H(3).Text = 'Range: 0.1-0.3. Canny sensitivity';
    L(4).Text = 'Line str';     H(4).Text = 'Range: 0.5-1. Higher=line darkness';
    E(1).Value = 0.06; E(2).Value = 300; E(3).Value = 0.15; E(4).Value = 0.9;
end
end

function loadImage(fig)
try
    [filename, pathname] = uigetfile({'*.jpg;*.jpeg;*.png;*.bmp;*.tif;*.tiff', 'Image files'; '*.*', 'All'}, 'Select image');
    if isequal(filename, 0) || isequal(pathname, 0), return; end
    img = imread(fullfile(pathname, filename));
    if size(img, 3) == 1, img = repmat(img, [1 1 3]); end
    fig.UserData.img = im2double(img);
    [~, fig.UserData.filename, ~] = fileparts(filename);
    fig.UserData.result = [];
    displayInAxes(fig.UserData.axComp, fig.UserData.img);
    fig.UserData.evalLabel.Text = '';
    fig.UserData.statusLabel.Text = sprintf('Loaded: %s', filename);
    try, fig.UserData.slider.Enable = 'off'; catch, end
catch ME
    fig.UserData.statusLabel.Text = ['Load error: ' ME.message];
    errordlg(ME.message, 'Load Image Error');
end
end

function processImage(fig)
if isempty(fig.UserData.img)
    fig.UserData.statusLabel.Text = 'Please load an image first.';
    return;
end
fig.UserData.statusLabel.Text = 'Processing...';
fig.UserData.evalLabel.Text = '';
drawnow;
img = fig.UserData.img;
style = fig.UserData.styleDrop.Value;
E = fig.UserData.paramEdits;
try
    t0 = tic;
    if strcmp(style, 'Poster / Pop Art')
        out = artify_poster(img, E(1).Value, round(E(2).Value), E(3).Value, E(4).Value);
    elseif strcmp(style, 'Cartoon')
        out = artify_cartoon(img, E(1).Value, E(2).Value, E(3).Value, round(E(4).Value));
    else
        out = artify_sketch(img, E(1).Value, round(E(2).Value), E(3).Value, E(4).Value);
    end
    elapsed = toc(t0);
    % Ensure output matches input size (Cartoon may resize for large images)
    if size(out, 1) ~= size(img, 1) || size(out, 2) ~= size(img, 2)
        out = imresize(out, [size(img, 1) size(img, 2)]);
    end
    fig.UserData.result = out;
    updateSliderView(fig);
    fig.UserData.slider.Enable = 'on';
    fig.UserData.slider.Value = 50;
    % Quantitative evaluation
    if exist('ssim', 'file')
        s = ssim(rgb2gray(img), rgb2gray(out));
        fig.UserData.evalLabel.Text = sprintf('SSIM: %.3f  |  Time: %.2f s', s, elapsed);
    else
        fig.UserData.evalLabel.Text = sprintf('Time: %.2f s', elapsed);
    end
    fig.UserData.statusLabel.Text = 'Done! Drag slider to compare.';
catch ME
    fig.UserData.statusLabel.Text = ['Error: ' ME.message];
end
end

function updateSliderView(fig)
if isempty(fig.UserData.result), return; end
img = fig.UserData.img;
res = fig.UserData.result;
[h, w, ~] = size(img);
if size(res, 1) ~= h || size(res, 2) ~= w
    res = imresize(res, [h w]);
end
v = fig.UserData.slider.Value / 100;  % 0=full Original, 100=full Result
split = round(w * v);
comp = img;  % start with Original
comp(:, 1:split, :) = res(:, 1:split, :);   % left of split = Result
comp(:, split+1:end, :) = img(:, split+1:end, :);  % right of split = Original
displayInAxes(fig.UserData.axComp, comp);
end

function displayInAxes(ax, img)
cla(ax);
image(ax, img);
axis(ax, 'image');
ax.XTick = []; ax.YTick = [];
end

function saveResult(fig)
if isempty(fig.UserData.result)
    fig.UserData.statusLabel.Text = 'Process an image first.';
    return;
end
folder = uigetdir(pwd, 'Select save folder');
if folder == 0, return; end
style = fig.UserData.styleDrop.Value;
suffix = lower(strrep(style, ' / ', '_'));
suffix = strrep(suffix, ' ', '_');
fpath = fullfile(folder, [fig.UserData.filename '_' suffix '.png']);
imwrite(fig.UserData.result, fpath);
fig.UserData.statusLabel.Text = sprintf('Saved: %s', fpath);
end
